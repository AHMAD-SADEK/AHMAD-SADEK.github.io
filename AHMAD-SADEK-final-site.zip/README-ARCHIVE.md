# Ahmad Sadek — Personal Archive

Use GitHub Issue Forms to publish content. Choose Published to make it appear on the site; Draft stays out of the site.
