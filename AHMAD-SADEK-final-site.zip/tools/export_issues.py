#!/usr/bin/env python3
import os,re,json
from urllib.request import Request,urlopen
repo=os.environ['GITHUB_REPOSITORY']; token=os.environ['GITHUB_TOKEN']
def get(url):
    req=Request(url,headers={'Accept':'application/vnd.github+json','Authorization':f'Bearer {token}','X-GitHub-Api-Version':'2022-11-28','User-Agent':'ahmad-sadek-archive'})
    with urlopen(req,timeout=30) as r:return json.load(r)
def sections(body):
    out={}; ms=list(re.finditer(r'(?m)^###\s+(.+?)\s*$',body or ''))
    for i,m in enumerate(ms):
        end=ms[i+1].start() if i+1<len(ms) else len(body or '')
        out[m.group(1).strip()]=(body[m.end():end]).strip()
    return out
def first(d,*keys):
    for k in keys:
        if d.get(k,'').strip():return d[k].strip()
    return ''
def norm_category(v):
    s=v.lower()
    if 'medicine' in s or 'pharmacy' in s:return 'pharmacy'
    if 'engineering' in s or 'technology' in s:return 'engineering'
    if 'thought' in s or 'philosophy' in s or 'humanit' in s:return 'thought'
    if 'personal' in s:return 'personal'
    return 'general'
def type_from_labels(issue):
    labels=[x.get('name','').lower() for x in issue.get('labels',[])]
    mapped={'content-article':'writing','content-research':'research','content-book':'book','content-project':'project','content-idea':'idea','content-personal':'personal'}
    for lab,typ in mapped.items():
        if lab in labels:return typ
    title=(issue.get('title') or '').lower()
    prefixes={'[article / مقال] ':'writing','[research / بحث] ':'research','[book / كتاب] ':'book','[project / مشروع] ':'project','[idea / فكرة] ':'idea','[personal / شخصي] ':'personal'}
    for prefix,typ in prefixes.items():
        if title.startswith(prefix):return typ
    return ''
def slug(s,n):
    s=re.sub(r'[^a-z0-9\u0600-\u06ff]+','-',(s or '').lower()).strip('-')[:70] or 'entry'
    return f'{s}-{n}'
items=[]
for page in range(1,100):
    xs=get(f'https://api.github.com/repos/{repo}/issues?state=all&per_page=100&page={page}')
    xs=[x for x in xs if 'pull_request' not in x]
    if not xs:break
    for issue in xs:
        f=sections(issue.get('body') or ''); labels=[x.get('name','').lower() for x in issue.get('labels',[])]
        typ=type_from_labels(issue); status=first(f,'Publication Status / حالة النشر','Publication Status','Status')
        if not typ or ('published' not in status.lower() and 'published' not in labels):continue
        title=first(f,'Title / العنوان','Title / عنوان الكتاب','Title') or issue.get('title','')
        date=first(f,'Date / التاريخ','Publication Date / تاريخ النشر','Publication Date') or issue.get('created_at','')[:10]
        item={'id':slug(title,issue['number']),'issueNumber':issue['number'],'type':typ,'category':norm_category(first(f,'Category / التصنيف','Category')),'title':title,'subtitle':first(f,'Subtitle / العنوان الفرعي','Subtitle'),'author':first(f,'Author / الكاتب','Author / المؤلف','Author') or 'Ahmad Sadek','authors':first(f,'Authors / الباحثون','Authors'),'date':date,'language':first(f,'Language / اللغة','Language'),'tags':[x.strip() for x in first(f,'Tags / الوسوم','Tags').split(',') if x.strip()],'readingTime':first(f,'Reading Time / مدة القراءة','Reading Time'),'abstract':first(f,'Abstract / Summary / الملخص','Abstract / الملخص','Description / وصف الكتاب','Summary / الملخص'),'content':first(f,'Content / المحتوى','Book Text / نص الكتاب','Case Study / تفاصيل المشروع','Idea / الفكرة','Content'),'secondLanguage':first(f,'Second Language Version / النسخة باللغة الثانية','Second Language Version'),'coverImage':first(f,'Cover Image / صورة الغلاف','Book Cover / غلاف الكتاب','Cover Image'),'references':first(f,'References / المراجع','References'),'files':first(f,'PDF / Files','PDF / البحث بصيغة PDF','PDF / ملف الكتاب','Files / الملفات'),'technologies':first(f,'Technologies / التقنيات','Technologies'),'projectStatus':first(f,'Project Status / حالة المشروع','Project Status'),'links':first(f,'Links / الروابط','Links'),'sourceUrl':issue['html_url'],'createdAt':issue['created_at']}
        items.append(item)
items.sort(key=lambda x:x.get('date') or x.get('createdAt',''),reverse=True)
os.makedirs('data',exist_ok=True)
with open('data/content.json','w',encoding='utf-8') as fp:json.dump({'generatedAt':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'items':items},fp,ensure_ascii=False,indent=2)
print('Exported',len(items),'published entries.')
